//
//  ShowDetailsTableViewController.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation

class ShowDetailsTableViewController: NSObject {
    
    var showName = String()
    var episodeList = [EpisodeInfo]()
    
}
