//
//  ShowListTableViewController.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation

class ShowListTableViewController: NSObject {

    let dispatchGroup = DispatchGroup()
    var showList = [ShowInfo]()
    var jsonList = ["Title", "Director", "Writer", "imdbRating", "Plot", "Poster"]
    
    //main function to get and set information for the 3 shows
    func setupData() {
        if ConnectionCheck.isConnectedToNetwork() {
            let theOffice = ShowInfo(title: "The Office", numberOfEpisodes: 9)
            for episodeNumber in 1...theOffice.numberOfEpisodes {
                //called this to provide a way to sequence the episodes called in order for the api
                dispatchGroup.enter()
                OMDbAPI.getEpisodeInfo(showTitle: theOffice.title, episodeNumber: episodeNumber, jsonList: self.jsonList) { (title, director, writer, episodeRating, plotSummary, posterImage, noData) in
                    let convertRating = Double(episodeRating)
                    let episodeInfo = EpisodeInfo(title: title, director: director, writer: writer, episodeRating: ((convertRating!)/2.0), plotSummary: plotSummary, posterImage: posterImage, episodeNumber: "\(episodeNumber)", noData: noData)
                        theOffice.episodeInfo.append(episodeInfo)
                        self.dispatchGroup.leave()
                }
                self.dispatchGroup.wait()
            }
            showList.append(theOffice)
            
            let parksAndRec = ShowInfo(title: "Parks and Recreation", numberOfEpisodes: 6)
            for episodeNumber in 1...parksAndRec.numberOfEpisodes {
                dispatchGroup.enter()
                OMDbAPI.getEpisodeInfo(showTitle: parksAndRec.title, episodeNumber: episodeNumber, jsonList: self.jsonList) { (title, director, writer, episodeRating, plotSummary, posterImage, noData) in
                    let convertRating = Double(episodeRating)
                    let episodeInfo = EpisodeInfo(title: title, director: director, writer: writer, episodeRating: ((convertRating!)/2.0), plotSummary: plotSummary, posterImage: posterImage, episodeNumber: "\(episodeNumber)", noData: noData)
                        parksAndRec.episodeInfo.append(episodeInfo)
                        self.dispatchGroup.leave()
                }
                self.dispatchGroup.wait()
            }
            showList.append(parksAndRec)

            let theGoodPlace = ShowInfo(title: "The Good Place", numberOfEpisodes: 13)
            for episodeNumber in 1...theGoodPlace.numberOfEpisodes {
                dispatchGroup.enter()
                OMDbAPI.getEpisodeInfo(showTitle: theGoodPlace.title, episodeNumber: episodeNumber, jsonList: self.jsonList) { (title, director, writer, episodeRating, plotSummary, posterImage, noData) in
                    let convertRating = Double(episodeRating)
                    let episodeInfo = EpisodeInfo(title: title, director: director, writer: writer, episodeRating: ((convertRating!)/2.0), plotSummary: plotSummary, posterImage: posterImage, episodeNumber: "\(episodeNumber)", noData: noData)
                        theGoodPlace.episodeInfo.append(episodeInfo)
                    self.dispatchGroup.leave()
                }
                self.dispatchGroup.wait()
            }
            showList.append(theGoodPlace)
            
        } else {
            //in case there is no internet connectivity, this will notify the screen to show the alert for no connection
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "noConnection"), object: nil)
            
        }
    }
    
}
