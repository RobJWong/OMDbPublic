//
//  Alerts.swift
//  OMDb
//
//  Created by Robert Wong on 8/17/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation
import UIKit

public class AlertBox {
    
    struct alertBoxProperties {
        static let applicationName = "OMDb"
        static let applicationDismiss = "Ok"
    }

    class func sendAlert(boxMessage: String, presentingController: UIViewController) {
        let alertController = UIAlertController(title: alertBoxProperties.applicationName, message: boxMessage, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: alertBoxProperties.applicationDismiss, style: .default, handler: nil))
        presentingController.present(alertController, animated: true, completion: nil)
    }
}
