//
//  OMDbAPI.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation
import SwiftyJSON

public class OMDbAPI {
    //function to obtain the episode using the parameters of the show's title and episode number. a completion block is also passed in to send back the obtained json data from the API call
    class func getEpisodeInfo(showTitle: String, episodeNumber: Int, jsonList: [String], completion: @escaping(String, String, String, String, String, String, Bool) -> () ) {
        
        //I separated the url builder as it's own separate class
        let url = URLBuilder.buildURL(showTitle: showTitle, episodeNumber: episodeNumber)
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error?.localizedDescription)
            } else {
                if let json = try? JSON(data: data!) {
                    //here the defining factor of what constitues a valid response is if 'Response' had a value of true then all the values below exists. otherwise the messeages below will be the text of their respective labels.
                    if json["Response"] == "True" {
                        let dataTitle = json["\(jsonList[0])"].string ?? "Issue getting title"
                        let dataDirector = json["\(jsonList[1])"].string ?? "Issue getting director"
                        let dataWriter = json["\(jsonList[2])"].string ?? "Issue getting writer"
                        let dataEpisodeRating = json["\(jsonList[3])"].string ?? "0.0"
                        let dataPlot = json["\(jsonList[4])"].string ?? "Issue getting plot"
                        let dataPoster = json["\(jsonList[5])"].string ?? "Issue getting poster"
                        completion(dataTitle, dataDirector, dataWriter, dataEpisodeRating, dataPlot, dataPoster, false)
                    } else {
                        completion("Sorry. The episode info is not available", "Sorry. The episode info is not available", "Sorry. The episode info is not available", "0.0", "Sorry. The episode info is not available", "\(showTitle).png", true)
                    }
                }
            }
        }
        task.resume()
    }
}
