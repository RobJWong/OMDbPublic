//
//  URLBuilder.swift
//  Helpers
//
//  Created by Robert Wong on 8/17/19.
//

import Foundation

public class URLBuilder {
    
    //builds the api url based on the show title and episode number and returns it
    class func buildURL(showTitle: String, episodeNumber: Int) -> URL {
        
        let OMDbAPIKey = "92582e55"
        let OMDbURL = "omdbapi.com"
        let seasonNumber = "1"
        let urlScheme = "http"
        let showName = "t"
        let season = "season"
        let apiKey = "apikey"
        let episode = "episode"
        
        var components = URLComponents()
        components.scheme = urlScheme
        components.host = OMDbURL
        components.queryItems = [
            URLQueryItem(name: "\(showName)", value: showTitle),
            URLQueryItem(name: "\(season)", value: seasonNumber),
            URLQueryItem(name: "\(apiKey)", value: OMDbAPIKey),
            URLQueryItem(name: "\(episode)", value: "\(episodeNumber)")
        ]
        
        let url = components.url!
        
        return url
    }
}
