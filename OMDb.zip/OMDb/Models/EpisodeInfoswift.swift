//
//  EpisodeInfo.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation

class EpisodeInfo {
    
    var title = String()
    var director = String()
    var writer = String()
    var plotSummary = String()
    var posterImage = String()
    var episodeNumber = String()
    var episodeRating = Double()
    var noData = Bool()

    init(title: String, director: String, writer: String, episodeRating: Double, plotSummary: String, posterImage: String, episodeNumber: String, noData: Bool) {
        self.title = title
        self.director = director
        self.writer = writer
        self.plotSummary = plotSummary
        self.posterImage = posterImage
        self.episodeNumber = episodeNumber
        self.episodeRating = episodeRating
        self.noData = noData
    }
}
