//
//  ShowInfo.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import Foundation

class ShowInfo {
    
    var title = String()
    var numberOfEpisodes = Int()
    var episodeInfo = [EpisodeInfo]()
    
    init(title: String, numberOfEpisodes: Int) {
        self.title = title
        self.numberOfEpisodes = numberOfEpisodes
    }
}
