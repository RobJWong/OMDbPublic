//
//  OMDbTests.swift
//  OMDbTests
//
//  Created by Robert Wong on 8/15/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import XCTest
@testable import OMDb

class OMDbTests: XCTestCase {
    
    private var sampleData = ShowListTableViewController()
    var showList = [ShowInfo]()
    var jsonList = [String]()
    
    override func setUp() {
        super.setUp()
        
        //need to access these to test for show data, episode
        sampleData.setupData()
        showList = sampleData.showList
        jsonList = sampleData.jsonList
    }
    
    func testNumberOfShows() {
        
        //This is to make sure that only the 3 shows are entered into the show list and no extras were entered or removed
        XCTAssertEqual(showList.count, 3)
    }
    
    func testNumberOfEpisodes() {
        
        //The number of episodes were also hardcoded because the OMDb API returns only episodes that are in the system but not actual episode count per show for season 1. So if I was to count the number of episodes from season 1 of The Office, it would return a count of 4 versus a count of 9.
        
        XCTAssertEqual(showList[0].numberOfEpisodes, 9)
 
        XCTAssertEqual(showList[1].numberOfEpisodes, 6)
        
        XCTAssertEqual(showList[2].numberOfEpisodes, 13)
    }
    
    func testShowTitle() {

        //Double checks that the show names are entered correctly
        XCTAssertEqual(showList[0].title, "The Office")
        
        XCTAssertEqual(showList[1].title, "Parks and Recreation")
        
        XCTAssertEqual(showList[2].title, "The Good Place")
    }
    
    func testOMDbAPIURL() {
        
        //Checks if the URL was built right
        let correctOMDbURL: URL = URL(string: "http://omdbapi.com?t=The%20Office&season=1&apikey=869c8c13&episode=2")!
        let testedOMDbURL = URLBuilder.buildURL(showTitle: "The Office", episodeNumber: 2)
        XCTAssertEqual(testedOMDbURL, correctOMDbURL)
    }
    
    func testJSONLabels() {
        
        //Makes sures that the JSON labels are correctly ordered and labeled
        XCTAssertEqual(jsonList[0], "Title")
        
        XCTAssertEqual(jsonList[1], "Director")
        
        XCTAssertEqual(jsonList[2], "Writer")
        
        XCTAssertEqual(jsonList[3], "Plot")
        
        XCTAssertEqual(jsonList[4], "Poster")
    }
}
