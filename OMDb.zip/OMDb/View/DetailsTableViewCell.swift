//
//  DetailsTableViewCell.swift
//  OMDb
//
//  Created by Robert Wong on 8/17/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import UIKit
import Cosmos

class DetailsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellContainer: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var directorLabel: UILabel!
    @IBOutlet weak var writerLabel: UILabel!
    @IBOutlet weak var plotSummaryLabel: UILabel!
    @IBOutlet weak var episodeNumberLabel: UILabel!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var rating: CosmosView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        setupViews()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setupViews() {
        cellContainer.layer.cornerRadius = 15
        posterImage.layer.cornerRadius = 15
    }

}
