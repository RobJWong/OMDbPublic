//
//  ShowDetailsTableView.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import UIKit
import Kingfisher

class ShowDetailsTableView: UITableViewController {
    
    @IBOutlet weak var showTitle: UILabel!
    
    var showDetailsController = ShowDetailsTableViewController()

    override func viewDidLoad() {
        super.viewDidLoad()

        //setups the table and navigation title
        setupTableView()
        setupNavBar()
    }
    
    func setupNavBar() {
        self.navigationItem.title = "\(showDetailsController.showName) Details";
    }

    func setupTableView() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 750
        showTitle.text = "\(self.showDetailsController.showName)"
        self.view.reloadInputViews()
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return showDetailsController.episodeList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! DetailsTableViewCell
        //sets the cell's labels and images
        cell.episodeNumberLabel.text = "Episode \(showDetailsController.episodeList[indexPath.row].episodeNumber)"
        cell.titleLabel.text = showDetailsController.episodeList[indexPath.row].title
        cell.directorLabel.text = showDetailsController.episodeList[indexPath.row].director
        cell.writerLabel.text = showDetailsController.episodeList[indexPath.row].writer
        cell.rating.rating = Double(showDetailsController.episodeList[indexPath.row].episodeRating)
        cell.plotSummaryLabel.text = showDetailsController.episodeList[indexPath.row].plotSummary
        if showDetailsController.episodeList[indexPath.row].noData == false {
            cell.posterImage.kf.setImage(with: URL(string: showDetailsController.episodeList[indexPath.row].posterImage))
        } else {
            cell.posterImage.image = UIImage(named: "\(showDetailsController.showName).png")
        }
        return cell
    }
}
