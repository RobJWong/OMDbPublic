//
//  ShowListTableView.swift
//  OMDb
//
//  Created by Robert Wong on 8/16/19.
//  Copyright © 2019 Robert Wong. All rights reserved.
//

import UIKit

class ShowListTableView: UITableViewController {
    
    var showListController = ShowListTableViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Observers for checking network connectivity and when the app is active again
        NotificationCenter.default.addObserver(self, selector: #selector(self.noConnection(notification:)), name: NSNotification.Name(rawValue: "noConnection"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(reloadViews(notification:)), name: UIApplication.didBecomeActiveNotification, object: nil)
        
        //setup data and views
        showListController.setupData()
        setupTableRows()
    }
    
    //reloads the view if there was no data and there is a network connection
    @objc func reloadViews(notification: Notification) {
        if showListController.showList.isEmpty && ConnectionCheck.isConnectedToNetwork() {
            showListController.setupData()
            tableView.reloadData()
        }
    }
    
    
    //notifies the user if there is no connection
    @objc func noConnection(notification: Notification) {
        AlertBox.sendAlert(boxMessage: "There is no internet connectivity. Please check your connection.", presentingController: self)
    }
    
    //passes the EpisodeInfo array to the next screen to show episode details
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetails" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
            let showDetails = segue.destination as? ShowDetailsTableView
            showDetails?.showDetailsController.episodeList = self.showListController.showList[indexPath.row].episodeInfo
            showDetails?.showDetailsController.showName = self.showListController.showList[indexPath.row].title
            }
        }
    }
    
    //sets up the custom row height for each photo
    func setupTableRows() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 250
        tableView.tableFooterView = UIView(frame: CGRect.zero)
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return showListController.showList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "showInfoCell", for: indexPath) as! ShowTableViewCell
            
        cell.showLogo.image = UIImage(named: "\(showListController.showList[indexPath.row].title).png")

        return cell
    }
    
    //called remove observers for reallocating resources
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

}
